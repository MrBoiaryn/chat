export interface MessageInterface {
  key?: string;
  message: string;
  time: string;
  sender: string;
}
