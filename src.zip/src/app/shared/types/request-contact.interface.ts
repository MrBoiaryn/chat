export interface RequestContactInterface {
  name: string;
}
