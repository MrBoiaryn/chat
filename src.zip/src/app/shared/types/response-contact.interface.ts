import { ContactInterface } from './contact.interface';

export interface ResponseContactInterface {
  [key: string]: ContactInterface;
}
